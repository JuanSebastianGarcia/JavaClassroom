public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("¡Hola Mundo desde el servicio de ejecución!");
        System.out.println("Este es un programa de prueba.");
        System.out.println("Funciona correctamente si ves este mensaje.");
    }
}